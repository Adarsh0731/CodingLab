const express = require('express');
const router = express.Router();
const { courses, testimonials, services, stats, whyChooseUs } = require('../data/siteData');

router.get('/', (req, res) => {
  res.render('index', {
    title: 'TriumphsLab | Practical IT Training & Career Support',
    courses: courses.filter(c => c.featured),
    testimonials,
    services,
    stats,
    whyChooseUs
  });
});

router.get('/about', (req, res) => {
  res.render('about', { title: 'About Us - TriumphsLab', services });
});

router.get('/Contact', (req, res) => {
  res.render('contact', { title: 'Contact Us - TriumphsLab', services });
});

router.get('/Job_listing', (req, res) => {
  res.render('jobs', { title: 'Job Listing - TriumphsLab', services });
});

router.get('/Mock_interview', (req, res) => {
  res.render('service', { title: 'Mock Interview - TriumphsLab', service: services[0], services });
});
router.get('/Become_a_trainer', (req, res) => {
  res.render('service', { title: 'Become a Trainer - TriumphsLab', service: services[1], services });
});
router.get('/Internship', (req, res) => {
  res.render('service', { title: 'Internship - TriumphsLab', service: services[2], services });
});
router.get('/International_certification', (req, res) => {
  res.render('service', { title: 'International IT Certification - TriumphsLab', service: services[3], services });
});
router.get('/Resume_building', (req, res) => {
  res.render('service', { title: 'Resume Building - TriumphsLab', service: services[4], services });
});

module.exports = router;
