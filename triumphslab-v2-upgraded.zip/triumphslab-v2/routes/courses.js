const express = require('express');
const router = express.Router();
const { courses, services } = require('../data/siteData');
const { getEmbedUrl } = require('../data/courseVideos');
const db = require('../data/db');

router.get('/', (req, res) => {
  res.render('courses', { title: 'All Courses - TriumphsLab', courses, services });
});

const courseRoutes = [
  'Manual_testing', 'Java_with_selenium', 'Devops_course',
  'Appium', 'Performance_testing', 'Api_testing_postman',
  'Api_automation_rest', 'Manual_testing_video'
];

courseRoutes.forEach(slug => {
  router.get(`/${slug}`, (req, res) => {
    const course = courses.find(c => c.slug === slug) || courses[0];
    // getEmbedUrl normalises any YouTube URL/ID to a proper embed URL
    const videoUrl = getEmbedUrl(course.id);

    // Check enrollment server-side so access is immediate (no spinner flash)
    let isEnrolled = false;
    if (req.session && req.session.user) {
      isEnrolled = !!db.enrollments.find(
        e => e.userId === req.session.user.id && e.courseId === course.id
      );
    }

    res.render('course-detail', {
      title: `${course.title} - TriumphsLab`,
      course,
      services,
      videoUrl,
      isEnrolled
    });
  });
});

module.exports = router;
