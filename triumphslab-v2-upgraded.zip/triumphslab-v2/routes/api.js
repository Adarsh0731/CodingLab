const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { courses, testimonials } = require('../data/siteData');
const db = require('../data/db');

function getTransporter() {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
  });
}

async function sendMail(opts) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.warn('Email not configured — skipping send.');
    return;
  }
  try {
    const t = getTransporter();
    await t.sendMail({ from: `"TriumphsLab" <${process.env.EMAIL_USER}>`, ...opts });
  } catch (err) {
    console.error('Email error:', err.message);
  }
}

async function sendEnrollmentEmail({ name, email, phone, course }) {
  await sendMail({
    to: process.env.EMAIL_TO || 'udayhiremath704@gmail.com',
    subject: `New Enrollment Interest: ${course}`,
    html: `<h2>New Course Enrollment Interest</h2><p><b>Name:</b> ${name}</p><p><b>Email:</b> ${email}</p><p><b>Phone:</b> ${phone}</p><p><b>Course:</b> ${course}</p><p><b>Time:</b> ${new Date().toLocaleString('en-IN')}</p>`
  });
  await sendMail({
    to: email,
    subject: `Thank you for your interest in ${course} - TriumphsLab`,
    html: `<div style="font-family:Arial,sans-serif;max-width:600px"><h2 style="color:#6c63ff">TriumphsLab</h2><p>Hi <b>${name}</b>,</p><p>Thank you for your interest in <b>${course}</b>!</p><p>Our team will contact you within 24 hours to confirm access.</p><p>📞 (+91) 9148819085 | 📧 udayhiremath704@gmail.com</p><p>– Team TriumphsLab</p></div>`
  });
}

async function sendContactEmail({ name, email, phone, message }) {
  await sendMail({
    to: process.env.EMAIL_TO || process.env.EMAIL_USER,
    subject: `Contact Form: ${name}`,
    html: `<p><b>Name:</b> ${name}</p><p><b>Email:</b> ${email}</p><p><b>Phone:</b> ${phone || 'N/A'}</p><p><b>Message:</b> ${message}</p>`
  });
}

async function sendCertificateEmail({ name, email, courseName, score, total, certId, date }) {
  const pct = Math.round((score / total) * 100);
  await sendMail({
    to: email,
    subject: `🎓 Your TriumphsLab Certificate — ${courseName}`,
    html: `<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;background:#f8f7ff;padding:32px;border-radius:12px">
  <div style="text-align:center;margin-bottom:24px">
    <h1 style="color:#6c63ff;font-size:28px;margin:0">🏆 TriumphsLab</h1>
    <p style="color:#888;font-size:14px;margin:4px 0">Practical IT Training & Career Support</p>
  </div>
  <div style="background:#fff;border-radius:16px;padding:40px;border:3px solid #6c63ff;text-align:center">
    <p style="color:#888;font-size:14px;letter-spacing:2px;text-transform:uppercase;margin:0 0 8px">Certificate of Completion</p>
    <p style="color:#444;font-size:16px;margin:0 0 16px">This is to certify that</p>
    <h2 style="color:#222;font-size:32px;margin:0 0 16px;font-weight:800">${name}</h2>
    <p style="color:#444;font-size:16px;margin:0 0 4px">has successfully completed the quiz for</p>
    <h3 style="color:#6c63ff;font-size:22px;margin:8px 0 24px;font-weight:700">${courseName}</h3>
    <div style="display:inline-block;background:#f0efff;border-radius:12px;padding:16px 32px;margin-bottom:24px">
      <p style="color:#6c63ff;font-size:36px;font-weight:800;margin:0">${pct}%</p>
      <p style="color:#888;font-size:14px;margin:4px 0 0">Score: ${score} / ${total}</p>
    </div>
    <p style="color:#888;font-size:13px;margin:0">Date: ${date}</p>
    <p style="color:#bbb;font-size:12px;margin:4px 0 0">Certificate ID: ${certId}</p>
  </div>
  <div style="text-align:center;margin-top:24px">
    <p style="color:#888;font-size:13px">Keep this email as proof of your achievement.</p>
    <p style="color:#6c63ff;font-weight:700;font-size:14px">– Team TriumphsLab</p>
  </div>
</div>`
  });
}

db.passwordResets = db.passwordResets || {};

// Contact
router.post('/contact', async (req, res) => {
  const { name, email, phone, message } = req.body;
  if (!name || !email || !message) return res.json({ success: false, message: 'Please fill all required fields.' });
  await sendContactEmail({ name, email, phone, message });
  res.json({ success: true, message: 'Thank you! We will contact you shortly.' });
});

// Enroll interest (does NOT grant video access — admin must grant from dashboard)
router.post('/enroll', async (req, res) => {
  const { name, email, phone, course } = req.body;
  if (!name || !email || !phone || !course) return res.json({ success: false, message: 'Please fill all required fields.' });
  const courseObj = courses.find(c => c.title === course);
  const userId = req.session && req.session.user ? req.session.user.id : null;
  db.leads = db.leads || [];
  const courseIdForLead = courseObj ? courseObj.id : course;
  const alreadySubmitted = db.leads.find(l => l.email === email && l.courseId === courseIdForLead);
  if (alreadySubmitted) {
    return res.json({ success: true, message: 'You have already submitted an interest request for this course. Our team will contact you soon!' });
  }
  db.leads.push({ id: (db.leads.length + 1), userId, courseId: courseIdForLead, name, email, phone, course, createdAt: new Date() });
  await sendEnrollmentEmail({ name, email, phone, course });
  res.json({ success: true, message: 'Thank you for your interest! Our team will contact you within 24 hours and grant access once confirmed.' });
});

// Video access check
router.get('/video-access/:courseId', (req, res) => {
  if (!req.session || !req.session.user) return res.json({ access: false, reason: 'login' });
  const hasAccess = db.enrollments.find(e => e.userId === req.session.user.id && e.courseId === req.params.courseId);
  res.json({ access: !!hasAccess });
});

// Forgot Password — Send OTP
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.json({ success: false, message: 'Email is required.' });
  const user = db.users.find(u => u.email === email);
  if (!user) return res.json({ success: true, message: 'If an account with that email exists, you will receive an OTP.' });
  const otp = crypto.randomInt(100000, 999999).toString();
  db.passwordResets[email] = { otp, expiresAt: Date.now() + 10 * 60 * 1000 };
  await sendMail({
    to: email,
    subject: 'TriumphsLab — Password Reset OTP',
    html: `<div style="font-family:Arial,sans-serif;max-width:480px"><h2 style="color:#6c63ff">TriumphsLab Password Reset</h2><p>Hi <b>${user.firstname}</b>,</p><p>Use the OTP below to reset your password. It expires in <b>10 minutes</b>.</p><div style="background:#f0efff;border-radius:12px;padding:24px;text-align:center;margin:24px 0"><p style="font-size:36px;font-weight:800;color:#6c63ff;letter-spacing:8px;margin:0">${otp}</p></div><p style="color:#888;font-size:13px">If you did not request this, ignore this email.</p><p>– Team TriumphsLab</p></div>`
  });
  res.json({ success: true, message: 'OTP sent to your email. Please check your inbox.' });
});

// Forgot Password — Verify OTP & Reset
router.post('/reset-password', async (req, res) => {
  const { email, otp, newPassword } = req.body;
  if (!email || !otp || !newPassword) return res.json({ success: false, message: 'All fields are required.' });
  if (newPassword.length < 6) return res.json({ success: false, message: 'Password must be at least 6 characters.' });
  const record = db.passwordResets[email];
  if (!record) return res.json({ success: false, message: 'No OTP found. Please request a new one.' });
  if (Date.now() > record.expiresAt) { delete db.passwordResets[email]; return res.json({ success: false, message: 'OTP expired. Please request a new one.' }); }
  if (record.otp !== otp.trim()) return res.json({ success: false, message: 'Incorrect OTP. Please try again.' });
  const user = db.users.find(u => u.email === email);
  if (!user) return res.json({ success: false, message: 'Account not found.' });
  user.password = await bcrypt.hash(newPassword, 10);
  delete db.passwordResets[email];
  res.json({ success: true, message: 'Password reset successfully. You can now log in.' });
});

// Quiz: get questions
router.get('/quiz/:courseId', (req, res) => {
  const questions = getQuizQuestions(req.params.courseId);
  if (!questions.length) return res.json({ success: false, message: 'No quiz available.' });
  res.json({ success: true, questions: questions.map(q => ({ id: q.id, question: q.question, options: q.options })) });
});

// Quiz: submit answers
router.post('/quiz/submit', (req, res) => {
  if (!req.session || !req.session.user) return res.json({ success: false, message: 'Please log in.' });
  const { courseId, answers } = req.body;
  const questions = getQuizQuestions(courseId);
  if (!questions.length) return res.json({ success: false, message: 'No quiz found.' });
  let score = 0;
  const results = questions.map(q => {
    const selected = answers[q.id];
    const correct = selected === q.answer;
    if (correct) score++;
    return { id: q.id, selected, correct, answer: q.answer };
  });
  res.json({ success: true, score, total: questions.length, results });
});

// Quiz: issue certificate
router.post('/quiz/certificate', async (req, res) => {
  if (!req.session || !req.session.user) return res.json({ success: false, message: 'Please log in.' });
  const { courseId, score, total } = req.body;
  if (score === undefined || !total || !courseId) return res.json({ success: false, message: 'Invalid quiz data.' });
  const pct = Math.round((score / total) * 100);
  if (pct < 60) return res.json({ success: false, passed: false, message: `You scored ${pct}%. You need at least 60% to receive a certificate. Please retry!` });
  const user = db.users.find(u => u.id === req.session.user.id);
  const course = courses.find(c => c.id === courseId);
  if (!user || !course) return res.json({ success: false, message: 'Invalid user or course.' });
  const certId = `TL-${Date.now()}-${user.id}`;
  const date = new Date().toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' });
  db.certificates = db.certificates || [];
  db.certificates.push({ certId, userId: user.id, courseId, score, total, date, createdAt: new Date() });
  await sendCertificateEmail({ name: `${user.firstname} ${user.lastname || ''}`.trim(), email: user.email, courseName: course.title, score, total, certId, date });
  res.json({ success: true, passed: true, pct, certId, message: `Congratulations! You scored ${pct}%. Your certificate has been sent to ${user.email}.` });
});

router.get('/courses', (req, res) => res.json({ success: true, data: courses }));
router.get('/testimonials', (req, res) => res.json({ success: true, data: testimonials }));

// Quiz Question Bank — reads from db (admin-managed)
function getQuizQuestions(courseId) {
  const questions = db.quizQuestions && db.quizQuestions[courseId];
  if (questions && questions.length) return questions;
  // fallback: manual-testing if unknown course
  return (db.quizQuestions && db.quizQuestions['manual-testing']) || [];
}

// LEGACY BANK KEPT ONLY AS REFERENCE — no longer used at runtime
function _legacyBank(courseId) {
  const bank = {
    'manual-testing': [
      { id: 1, question: 'What is the primary goal of software testing?', options: ['Write code', 'Find defects and ensure quality', 'Design UI', 'Deploy application'], answer: 'Find defects and ensure quality' },
      { id: 2, question: 'Which type of testing is performed without executing code?', options: ['Unit testing', 'Integration testing', 'Static testing', 'System testing'], answer: 'Static testing' },
      { id: 3, question: 'What does STLC stand for?', options: ['Software Test Life Cycle', 'System Test Logic Cycle', 'Software Test Logic Check', 'None of above'], answer: 'Software Test Life Cycle' },
      { id: 4, question: 'Which document describes what to test and how?', options: ['Bug Report', 'Test Plan', 'Test Case', 'RTM'], answer: 'Test Plan' },
      { id: 5, question: 'Boundary Value Analysis is a type of?', options: ['Black Box Testing', 'White Box Testing', 'Grey Box Testing', 'Regression Testing'], answer: 'Black Box Testing' },
      { id: 6, question: 'Which testing verifies the system against requirements?', options: ['Unit', 'Integration', 'System', 'UAT'], answer: 'System' },
      { id: 7, question: 'A defect found after release is called?', options: ['Bug', 'Error', 'Production Defect', 'Incident'], answer: 'Production Defect' },
      { id: 8, question: 'Equivalence Partitioning divides input into?', options: ['Valid classes only', 'Invalid classes only', 'Valid and invalid classes', 'Random partitions'], answer: 'Valid and invalid classes' },
      { id: 9, question: 'Which test level tests individual components?', options: ['Integration', 'System', 'Unit', 'Acceptance'], answer: 'Unit' },
      { id: 10, question: 'Regression testing is performed after?', options: ['Requirements change', 'Code changes or bug fixes', 'UI redesign only', 'Load testing'], answer: 'Code changes or bug fixes' },
    ],
    'java-selenium': [
      { id: 1, question: 'Which method finds elements by CSS selector in Selenium?', options: ['findElement(By.id)', 'findElement(By.cssSelector)', 'findElement(By.name)', 'findElement(By.tagName)'], answer: 'findElement(By.cssSelector)' },
      { id: 2, question: 'TestNG annotation to run before each test method?', options: ['@BeforeClass', '@BeforeSuite', '@BeforeMethod', '@BeforeTest'], answer: '@BeforeMethod' },
      { id: 3, question: 'Which design pattern is commonly used in Selenium frameworks?', options: ['Singleton', 'Page Object Model', 'Factory', 'Observer'], answer: 'Page Object Model' },
      { id: 4, question: 'What does driver.quit() do?', options: ['Closes current window', 'Closes all windows and ends session', 'Minimizes browser', 'Refreshes page'], answer: 'Closes all windows and ends session' },
      { id: 5, question: 'Which wait is most recommended in Selenium?', options: ['Thread.sleep', 'Implicit Wait', 'Explicit Wait (WebDriverWait)', 'Static Wait'], answer: 'Explicit Wait (WebDriverWait)' },
      { id: 6, question: 'How do you handle alerts in Selenium?', options: ['driver.alert()', 'driver.switchTo().alert()', 'driver.getAlert()', 'Alert a = new Alert()'], answer: 'driver.switchTo().alert()' },
      { id: 7, question: 'What is the use of the Actions class in Selenium?', options: ['Take screenshots', 'Handle keyboard & mouse events', 'Manage frames', 'Handle cookies'], answer: 'Handle keyboard & mouse events' },
      { id: 8, question: 'Which method clears a text field in Selenium?', options: ['.clear()', '.reset()', '.empty()', '.delete()'], answer: '.clear()' },
      { id: 9, question: 'XPath starting with // means?', options: ['Absolute path', 'Relative path from root', 'Relative path from anywhere', 'Parent element'], answer: 'Relative path from anywhere' },
      { id: 10, question: 'What does By.xpath() return?', options: ['A WebElement', 'A By locator', 'A String', 'An int'], answer: 'A By locator' },
    ],
    'devops': [
      { id: 1, question: 'What does CI/CD stand for?', options: ['Code Integration/Code Deployment', 'Continuous Integration/Continuous Delivery', 'Continuous Improvement/Continuous Design', 'None'], answer: 'Continuous Integration/Continuous Delivery' },
      { id: 2, question: 'Which tool is primarily used for container orchestration?', options: ['Docker', 'Jenkins', 'Kubernetes', 'Ansible'], answer: 'Kubernetes' },
      { id: 3, question: 'Git command to create a new branch?', options: ['git new branch', 'git branch <name>', 'git checkout <name>', 'git clone <name>'], answer: 'git branch <name>' },
      { id: 4, question: 'What is a Dockerfile?', options: ['A script to run containers', 'A file with instructions to build a Docker image', 'A Docker network config', 'A Kubernetes manifest'], answer: 'A file with instructions to build a Docker image' },
      { id: 5, question: 'Jenkins is primarily a?', options: ['Version control tool', 'CI/CD automation server', 'Container runtime', 'Cloud provider'], answer: 'CI/CD automation server' },
      { id: 6, question: 'Infrastructure as Code tool by HashiCorp?', options: ['Ansible', 'Chef', 'Terraform', 'Puppet'], answer: 'Terraform' },
      { id: 7, question: 'Which command pushes a Docker image to a registry?', options: ['docker push', 'docker upload', 'docker send', 'docker publish'], answer: 'docker push' },
      { id: 8, question: 'What is a Kubernetes Pod?', options: ['A physical server', 'Smallest deployable unit containing containers', 'A Docker image', 'A CI pipeline stage'], answer: 'Smallest deployable unit containing containers' },
      { id: 9, question: 'Ansible uses which language for playbooks?', options: ['JSON', 'XML', 'YAML', 'Python'], answer: 'YAML' },
      { id: 10, question: 'What does git merge do?', options: ['Creates a new branch', 'Combines two branches', 'Deletes a branch', 'Resets changes'], answer: 'Combines two branches' },
    ],
    'api-postman': [
      { id: 1, question: 'REST API status code for successful POST (created)?', options: ['200', '201', '204', '400'], answer: '201' },
      { id: 2, question: 'What HTTP method is used to update a resource partially?', options: ['PUT', 'POST', 'PATCH', 'DELETE'], answer: 'PATCH' },
      { id: 3, question: 'In Postman, where do you write test scripts?', options: ['Pre-request Script', 'Tests tab', 'Headers tab', 'Authorization tab'], answer: 'Tests tab' },
      { id: 4, question: 'Which status code means Unauthorized?', options: ['403', '404', '401', '500'], answer: '401' },
      { id: 5, question: 'What is an API Collection in Postman?', options: ['A folder of requests', 'A test assertion', 'An environment variable', 'A mock server'], answer: 'A folder of requests' },
      { id: 6, question: 'pm.response.code refers to?', options: ['Request URL', 'Response status code', 'Response body', 'Header value'], answer: 'Response status code' },
      { id: 7, question: 'Content-Type header for JSON APIs?', options: ['text/plain', 'application/xml', 'application/json', 'multipart/form-data'], answer: 'application/json' },
      { id: 8, question: 'Which Postman feature allows automated test runs?', options: ['Mock Server', 'Collection Runner', 'API Monitor', 'Flows'], answer: 'Collection Runner' },
      { id: 9, question: 'Status 404 means?', options: ['Server Error', 'Unauthorized', 'Not Found', 'Bad Request'], answer: 'Not Found' },
      { id: 10, question: 'Bearer token is used for?', options: ['Content negotiation', 'Authentication/Authorization', 'Caching', 'Compression'], answer: 'Authentication/Authorization' },
    ],
    'appium': [
      { id: 1, question: 'Appium is used for testing?', options: ['Web apps', 'Mobile apps (Android & iOS)', 'Desktop apps', 'Databases'], answer: 'Mobile apps (Android & iOS)' },
      { id: 2, question: 'Appium uses which protocol?', options: ['HTTP', 'WebDriver Protocol', 'FTP', 'SOAP'], answer: 'WebDriver Protocol' },
      { id: 3, question: 'Which capability specifies device name in Appium?', options: ['platformName', 'deviceName', 'appPackage', 'automationName'], answer: 'deviceName' },
      { id: 4, question: 'UIAutomator2 is used for?', options: ['iOS automation', 'Android automation', 'Web automation', 'API testing'], answer: 'Android automation' },
      { id: 5, question: 'Which tool inspects mobile element locators?', options: ['Chrome DevTools', 'Appium Inspector', 'Firebug', 'Postman'], answer: 'Appium Inspector' },
      { id: 6, question: 'XCUITest automation engine is for?', options: ['Android', 'iOS', 'Windows', 'Linux'], answer: 'iOS' },
      { id: 7, question: 'Mobile gestures in Appium are handled via?', options: ['Actions class', 'TouchAction/W3C Actions', 'JavascriptExecutor', 'Robot class'], answer: 'TouchAction/W3C Actions' },
      { id: 8, question: 'appPackage capability refers to?', options: ['App file path', 'Android app package name', 'App version', 'Device OS'], answer: 'Android app package name' },
      { id: 9, question: 'Desired Capabilities configure?', options: ['Test assertions', 'Session (device, app, platform)', 'Alerts', 'Screenshots'], answer: 'Session (device, app, platform)' },
      { id: 10, question: 'How do you tap an element in Appium (Java)?', options: ['element.click()', 'element.tap()', 'element.touch()', 'element.press()'], answer: 'element.click()' },
    ],
    'jmeter': [
      { id: 1, question: 'JMeter is primarily used for?', options: ['UI testing', 'Performance/Load testing', 'Security testing', 'Mobile testing'], answer: 'Performance/Load testing' },
      { id: 2, question: 'What is a Thread Group in JMeter?', options: ['A group of HTTP requests', 'A set of virtual users', 'A listener', 'A timer'], answer: 'A set of virtual users' },
      { id: 3, question: 'Which JMeter element sends HTTP requests?', options: ['Thread Group', 'HTTP Request Sampler', 'Listener', 'Timer'], answer: 'HTTP Request Sampler' },
      { id: 4, question: 'Throughput in JMeter means?', options: ['Response time', 'Number of requests per second', 'Error rate', 'Latency'], answer: 'Number of requests per second' },
      { id: 5, question: 'JMeter is written in?', options: ['Python', 'Java', 'Ruby', 'JavaScript'], answer: 'Java' },
      { id: 6, question: 'Ramp-up period defines?', options: ['Test duration', 'Time to start all threads', 'Number of loops', 'Response timeout'], answer: 'Time to start all threads' },
      { id: 7, question: 'Assertions in JMeter verify?', options: ['Add delays', 'Response content', 'Parameterise requests', 'Record tests'], answer: 'Response content' },
      { id: 8, question: 'CSV Data Set Config is used for?', options: ['Storing results', 'Data parameterisation from CSV', 'Monitoring', 'Recording'], answer: 'Data parameterisation from CSV' },
      { id: 9, question: '90th percentile response time means?', options: ['Average time', '90% of requests completed within this time', 'Maximum time', 'Minimum time'], answer: '90% of requests completed within this time' },
      { id: 10, question: 'Which listener shows aggregate results?', options: ['View Results Tree', 'Aggregate Report', 'View Results in Table', 'Backend Listener'], answer: 'Aggregate Report' },
    ],
    'api-rest': [
      { id: 1, question: 'REST stands for?', options: ['Remote State Transfer', 'Representational State Transfer', 'Remote Service Technology', 'Resource State Transfer'], answer: 'Representational State Transfer' },
      { id: 2, question: 'Which HTTP method is idempotent and safe?', options: ['POST', 'PUT', 'GET', 'DELETE'], answer: 'GET' },
      { id: 3, question: 'RestAssured is a Java library for?', options: ['UI testing', 'Mobile testing', 'API testing', 'Database testing'], answer: 'API testing' },
      { id: 4, question: 'given().when().then() is pattern of?', options: ['TestNG', 'JUnit', 'RestAssured BDD style', 'Cucumber'], answer: 'RestAssured BDD style' },
      { id: 5, question: 'Status code 500 means?', options: ['Not Found', 'Forbidden', 'Internal Server Error', 'Bad Request'], answer: 'Internal Server Error' },
      { id: 6, question: 'OAuth 2.0 is used for?', options: ['Data encryption', 'Authorization', 'Load testing', 'Caching'], answer: 'Authorization' },
      { id: 7, question: 'JSON path to extract value in RestAssured?', options: ['response.body()', 'response.jsonPath().get("key")', 'response.extract("key")', 'response.path("key")'], answer: 'response.jsonPath().get("key")' },
      { id: 8, question: 'HTTPS differs from HTTP by?', options: ['Faster speed', 'Encrypted communication (SSL/TLS)', 'Port 8080', 'No headers'], answer: 'Encrypted communication (SSL/TLS)' },
      { id: 9, question: 'Serialisation in API testing means?', options: ['Converting object to JSON/XML', 'Parsing response', 'Validating schema', 'Sending request'], answer: 'Converting object to JSON/XML' },
      { id: 10, question: 'Which annotation in TestNG marks a test?', options: ['@Test', '@TestCase', '@Verify', '@Check'], answer: '@Test' },
    ],
  };
  return bank[courseId] || bank['manual-testing'];
}


module.exports = router;
