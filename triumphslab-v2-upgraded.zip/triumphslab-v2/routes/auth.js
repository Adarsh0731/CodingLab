const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../data/db');

// GET Login
router.get('/Login', (req, res) => {
  if (req.session.user) return res.redirect(req.session.user.role === 'admin' ? '/admin' : '/dashboard');
  res.render('login', { title: 'Sign In - TriumphsLab', error: null });
});

// POST Login
router.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email);
  if (!user) return res.json({ success: false, message: 'Invalid email or password.' });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.json({ success: false, message: 'Invalid email or password.' });

  req.session.user = { id: user.id, firstname: user.firstname, email: user.email, role: user.role };
  res.json({ success: true, role: user.role, redirect: user.role === 'admin' ? '/admin' : '/dashboard' });
});

// GET Register
router.get('/Register', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.render('register', { title: 'Sign Up - TriumphsLab', error: null });
});

// POST Register
router.post('/api/register', async (req, res) => {
  const { firstname, lastname, email, phone, password } = req.body;
  if (!firstname || !email || !password) return res.json({ success: false, message: 'Please fill all required fields.' });

  if (db.users.find(u => u.email === email)) {
    return res.json({ success: false, message: 'Email already registered. Please login.' });
  }

  const hashed = await bcrypt.hash(password, 10);
  const user = { id: db.nextUserId++, firstname, lastname, email, phone, password: hashed, role: 'student', createdAt: new Date() };
  db.users.push(user);

  req.session.user = { id: user.id, firstname: user.firstname, email: user.email, role: 'student' };
  res.json({ success: true, redirect: '/dashboard' });
});

// GET Dashboard (student)
router.get('/dashboard', (req, res) => {
  if (!req.session.user) return res.redirect('/Login');
  if (req.session.user.role === 'admin') return res.redirect('/admin');

  const { courses } = require('../data/siteData');
  const courseVideos = require('../data/courseVideos');
  // Get courses this student enrolled in (admin-granted or self-enrolled)
  const myEnrollments = db.enrollments.filter(e => e.userId === req.session.user.id);
  const enrolledCourseIds = myEnrollments.map(e => e.courseId);

  // Build whatsapp links map: courseId -> whatsapp url (only for enrolled courses)
  const whatsappLinks = {};
  enrolledCourseIds.forEach(cid => {
    const entry = courseVideos[cid];
    if (entry && typeof entry === 'object' && entry.whatsapp) {
      whatsappLinks[cid] = entry.whatsapp;
    }
  });

  res.render('dashboard', {
    title: 'My Dashboard - TriumphsLab',
    courses,
    enrolledCourseIds,
    enrollments: myEnrollments,
    whatsappLinks
  });
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/Login');
});

module.exports = router;
