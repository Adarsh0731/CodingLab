const express = require('express');
const router = express.Router();
const db = require('../data/db');
const { courses } = require('../data/siteData');
const courseVideos = require('../data/courseVideos');

// Admin auth middleware
function isAdmin(req, res, next) {
  if (req.session.user && req.session.user.role === 'admin') return next();
  res.redirect('/Login');
}

// Admin Dashboard
router.get('/', isAdmin, (req, res) => {
  const students = db.users.filter(u => u.role === 'student');
  const studentEnrollments = db.enrollments.filter(e => e.userId !== null && e.userId !== undefined);

  const courseStats = courses.map(c => {
    const entry = courseVideos[c.id];
    const rawVideo = entry ? (typeof entry === 'string' ? entry : (entry.video || '')) : '';
    const whatsappUrl = entry && typeof entry === 'object' ? (entry.whatsapp || '') : '';
    return {
      ...c,
      enrolledCount: studentEnrollments.filter(e => e.courseId === c.id).length,
      videoUrl: rawVideo,
      whatsappUrl
    };
  });

  res.render('admin', {
    title: 'Admin Dashboard - TriumphsLab',
    students,
    enrollments: db.enrollments,
    studentEnrollments,
    courseStats,
    leads: (db.leads || []).slice().reverse().slice(0, 50),
    totalStudents: students.length,
    totalEnrollments: studentEnrollments.length,
    quizQuestions: db.quizQuestions || {}
  });
});

// Admin: Update YouTube URL for a course
router.post('/update-video', isAdmin, (req, res) => {
  const { courseId, youtubeUrl } = req.body;
  const existing = courseVideos[courseId];
  if (existing && typeof existing === 'object') {
    existing.video = youtubeUrl || '';
  } else {
    courseVideos[courseId] = { video: youtubeUrl || '', whatsapp: '' };
  }
  res.json({ success: true, message: 'Video URL updated.' });
});

// Admin: Update WhatsApp invite link for a course
router.post('/update-whatsapp', isAdmin, (req, res) => {
  const { courseId, whatsappUrl } = req.body;
  if (!courseId) return res.json({ success: false, message: 'Course ID required.' });
  const existing = courseVideos[courseId];
  if (existing && typeof existing === 'object') {
    existing.whatsapp = whatsappUrl || '';
  } else {
    courseVideos[courseId] = { video: '', whatsapp: whatsappUrl || '' };
  }
  res.json({ success: true, message: 'WhatsApp link updated.' });
});

// Admin: Grant video access to a student
router.post('/grant-access', isAdmin, (req, res) => {
  const { userId, courseId } = req.body;
  const exists = db.enrollments.find(e => e.userId == userId && e.courseId === courseId);
  if (!exists) {
    db.enrollments.push({ id: db.nextEnrollmentId++, userId: parseInt(userId), courseId, grantedByAdmin: true, createdAt: new Date() });
  }
  res.json({ success: true });
});

// Admin: Revoke video access
router.post('/revoke-access', isAdmin, (req, res) => {
  const { userId, courseId } = req.body;
  db.enrollments = db.enrollments.filter(e => !(e.userId == userId && e.courseId === courseId));
  res.json({ success: true });
});

// Admin: Add a new student manually
router.post('/add-student', isAdmin, async (req, res) => {
  const bcrypt = require('bcryptjs');
  const { firstname, lastname, email, phone, password } = req.body || {};
  if (!firstname || !email || !password) return res.json({ success: false, message: 'Name, email and password are required.' });
  if (db.users.find(u => u.email === email)) return res.json({ success: false, message: 'Email already registered.' });
  const hashed = await bcrypt.hash(password, 10);
  db.users.push({ id: db.nextUserId++, firstname, lastname: lastname || '', email, phone: phone || '', password: hashed, role: 'student', createdAt: new Date() });
  res.json({ success: true, message: 'Student account created successfully.' });
});

// ── QUIZ MANAGEMENT ──────────────────────────────────────────────────────────

// Get questions for a course (AJAX)
router.get('/quiz/:courseId', isAdmin, (req, res) => {
  const questions = (db.quizQuestions && db.quizQuestions[req.params.courseId]) || [];
  res.json({ success: true, questions });
});

// Add a new MCQ question to a course
router.post('/quiz/add', isAdmin, (req, res) => {
  const { courseId, question, options, answer } = req.body;
  if (!courseId || !question || !options || !answer) {
    return res.json({ success: false, message: 'All fields are required.' });
  }
  if (!Array.isArray(options) || options.length !== 4 || options.some(o => !o.trim())) {
    return res.json({ success: false, message: 'Exactly 4 non-empty options are required.' });
  }
  if (!options.includes(answer)) {
    return res.json({ success: false, message: 'Correct answer must match one of the options.' });
  }
  db.quizQuestions = db.quizQuestions || {};
  db.quizQuestions[courseId] = db.quizQuestions[courseId] || [];
  const existing = db.quizQuestions[courseId];
  const newId = existing.length > 0 ? Math.max(...existing.map(q => q.id)) + 1 : 1;
  existing.push({ id: newId, question: question.trim(), options: options.map(o => o.trim()), answer: answer.trim() });
  res.json({ success: true, message: 'Question added.', total: existing.length });
});

// Remove a question from a course
router.post('/quiz/remove', isAdmin, (req, res) => {
  const { courseId, questionId } = req.body;
  if (!courseId || questionId === undefined) {
    return res.json({ success: false, message: 'courseId and questionId required.' });
  }
  db.quizQuestions = db.quizQuestions || {};
  db.quizQuestions[courseId] = db.quizQuestions[courseId] || [];
  const before = db.quizQuestions[courseId].length;
  db.quizQuestions[courseId] = db.quizQuestions[courseId].filter(q => q.id !== parseInt(questionId));
  const after = db.quizQuestions[courseId].length;
  if (before === after) return res.json({ success: false, message: 'Question not found.' });
  res.json({ success: true, message: 'Question removed.', total: after });
});

module.exports = router;
