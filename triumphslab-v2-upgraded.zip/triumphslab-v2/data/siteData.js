const courses = [
  {
    id: 'manual-testing',
    slug: 'Manual_testing',
    title: 'Manual Testing Course',
    badge: 'Manual Testing',
    image: '/assets/img/courses/manual-testing.png',
    description: 'Learn core manual testing skills to identify bugs, ensure quality, and validate software — no automation needed.',
    duration: '60+ hours – Weekday/Weekend Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time Banking Project Scenarios',
    featured: true
  },
  {
    id: 'java-selenium',
    slug: 'Java_with_selenium',
    title: 'Java with Selenium',
    badge: 'Selenium',
    image: '/assets/img/courses/java-selenium.png',
    description: 'Learn automation testing using Selenium with Java. Build frameworks, write scripts, and automate real-time applications.',
    duration: '60+ hours – Weekday/Weekend Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time Project Scenarios',
    featured: true
  },
  {
    id: 'devops',
    slug: 'Devops_course',
    title: 'DevOps Course',
    badge: 'DevOps',
    image: '/assets/img/courses/devops.png',
    description: 'Learn CI/CD, Jenkins, Docker, Kubernetes, and more to bridge the gap between development and operations seamlessly.',
    duration: '60+ hours – Weekday Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time DevOps Scenarios',
    featured: true
  },
  {
    id: 'appium',
    slug: 'Appium',
    title: 'Appium (Mobile Automation)',
    badge: 'Appium',
    image: '/assets/img/courses/appium.png',
    description: 'Master mobile automation testing using Appium for Android and iOS applications.',
    duration: '40+ hours – Weekday/Weekend Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time Mobile App Scenarios',
    featured: false
  },
  {
    id: 'jmeter',
    slug: 'Performance_testing',
    title: 'Performance Testing Tool: JMeter',
    badge: 'JMeter',
    image: '/assets/img/courses/jmeter.png',
    description: 'Learn performance and load testing using Apache JMeter for web applications.',
    duration: '30+ hours – Weekday/Weekend Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time Performance Scenarios',
    featured: false
  },
  {
    id: 'api-postman',
    slug: 'Api_testing_postman',
    title: 'API Testing with POSTMAN',
    badge: 'Postman',
    image: '/assets/img/courses/postman.png',
    description: 'Learn API testing concepts and tools using Postman for REST and SOAP APIs.',
    duration: '25+ hours – Weekday/Weekend Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time API Scenarios',
    featured: false
  },
  {
    id: 'api-rest',
    slug: 'Api_automation_rest',
    title: 'API Automation using REST Assured',
    badge: 'REST Assured',
    image: '/assets/img/courses/restassured.png',
    description: 'Master API automation using REST Assured Java library for backend testing.',
    duration: '35+ hours – Weekday/Weekend Batches',
    mode: 'Only Online Training Available',
    projects: 'Real-time API Automation Scenarios',
    featured: false
  },
  {
    id: 'self-paced',
    slug: 'Manual_testing_video',
    title: 'Self Paced Learning',
    badge: 'Video Course',
    image: '/assets/img/courses/self-paced.png',
    description: 'Learn at your own pace with recorded video sessions covering complete software testing concepts.',
    duration: '60+ hours of recorded content',
    mode: 'Video Access – Learn Anytime',
    projects: 'Includes real-time project scenarios',
    featured: false
  }
];

const testimonials = [
  { name: 'Siddaling Natikar', role: 'Student', review: 'Thank you so much for an amazing course! I learned so much and you made even the more complex topics interesting and easier to follow through real-world scenarios and case studies. The course and all the materials are both comprehensive and informative.' },
  { name: 'Narayan M', role: 'Student', review: 'Excellent instructor. Personal attention to each candidate. Availability of study material. Continuous mocks and encouragement for the same. Assistance in all possible way throughout.' },
  { name: 'Puja Thombare', role: 'Student', review: 'Very professional training and active support throughout the course and post joining as well. Efforts in mock sessions really appreciated — that\'s what makes the actual interviews easier.' },
  { name: 'Dnyanesh Kedari', role: 'Student', review: 'This course is very well designed and the teacher is having real time knowledge on what\'s going on in the company. Once you complete this course and get the job you feel you know everything which is being used by your company. This course truly is turning point for me.' },
  { name: 'Shiv W', role: 'Student', review: 'I just wanted to tell you how much I\'ve learnt here. What an excellent instructor with well versed industrial experience that definitely helped us to grow and improve our skills. Thank you!' },
  { name: 'Shubhangi G', role: 'Student', review: 'It\'s extremely good and sir is really putting his 101% to train their students. The syllabus which they cover is very perfect to get a job. Efforts in mock sessions really appreciated. Highly Recommend.' },
  { name: 'Vrushali B', role: 'Student', review: 'It\'s a very professional training and active support in and post training. Thanks TriumphsLab and Team.' },
  { name: 'Shalaka Londhe', role: 'Student', review: 'A very Special Thanks to TriumphsLab! The way of teaching all concepts from basic to practical is fabulous. Placement Support and guidance given by Sir was too helpful for me for getting job as well as doing job for very first time in corporate sector.' },
  { name: 'Namrata Rajput', role: 'Student', review: 'Triumphslab online software class is one of the best class for software testing. Prabhu sir and his team was very helpful and co-operative. Their teaching method and strategy was very different. I think there are 90% students who have more than one offer letter in hand.' },
  { name: 'Soundarya A U', role: 'Student', review: 'I joined Triumpslab for manual testing course. This is very helpful because they will explain how to clear the interviews and also if you have any doubts they will explain clearly. It helped me to get the job easily.' },
  { name: 'Rishikesh Kurde', role: 'Student', review: 'TriumphsLab is different as compared to other training institutes. Here I got training in more practical way. It helped me to build my confidence during interviews and able to crack any technical interview easily.' },
  { name: 'Pratiksha Gunjal', role: 'Student', review: 'Triumphs Lab is the best for achieving your dreams. This class was excellent. Prabhu Sir\'s way of explaining the concept was very impressive. He ensured that everybody was participating and made the session engaging.' },
  { name: 'Akshay Jadhav', role: 'Student', review: 'Triumphs Lab training institute is an excellent resource for anyone looking for quality software testing courses. Daily interactions, Mock interviews, support at every stage are some of the main reasons to join this course.' },
  { name: 'Sandhya K', role: 'Student', review: 'I came across this class when I was absolutely depressed. I wasn\'t quite sure what to expect, but I am very pleased. All I can say is, I got what I dreamed of in a very short time and I wouldn\'t be where I am without Triumphs Lab.' },
  { name: 'Shubham Gunjal', role: 'Student', review: 'Triumphslab online software testing class is one of the best. Prabhu sir is Best mentor and his team is really helpful. I got job in my dream company with industry\'s best package. Mock interviews really helped me to boost my confidence level.' },
  { name: 'dinesh kumar', role: 'Student', review: 'Manual testing course by Prabhu sir changed my life. It taught me a mentality of always keep learning no matter what. I am very grateful to triumphslab — my salary almost doubled.' }
];

const services = [
  { title: 'Mock Interview', slug: 'Mock_interview', icon: '🎯', description: 'Practice with real interview scenarios conducted by industry experts.' },
  { title: 'Become a Trainer', slug: 'Become_a_trainer', icon: '👨‍🏫', description: 'Join our team of expert trainers and share your knowledge.' },
  { title: 'Internship for Students', slug: 'Internship', icon: '🎓', description: 'Get real-world experience with our internship programs.' },
  { title: 'International IT Certification', slug: 'International_certification', icon: '🏆', description: 'Get globally recognized IT certifications to boost your career.' },
  { title: 'Professional Resume Building', slug: 'Resume_building', icon: '📄', description: 'Build an ATS-friendly resume that gets noticed by top companies.' }
];

const stats = [
  { value: '1500+', label: 'Students Enrolled' },
  { value: '500+', label: 'Placed Students' },
  { value: '8', label: 'Technical Courses' },
  { value: '7+', label: 'Years Established' }
];

const whyChooseUs = [
  { title: 'Learn from MNC Professionals', icon: '🏢', description: 'All our trainers are working professionals from top MNCs, bringing firsthand industry knowledge and the latest best practices into the classroom.' },
  { title: 'Industry-Aligned Curriculum', icon: '📚', description: 'Stay ahead with up-to-date course content tailored to current industry trends and demands, giving you a competitive edge in the job market.' },
  { title: 'Hands-On Learning Approach', icon: '💻', description: 'We emphasize practical learning with live projects, case studies, and interactive sessions, helping you gain the confidence to apply your skills effectively.' },
  { title: 'Strong Community & Networking', icon: '🤝', description: 'Join a thriving community of learners, mentors, and alumni, expanding your professional network and opportunities.' },
  { title: 'Recorded Sessions for Future Reference', icon: '🎥', description: 'Missed a class? No problem! Get access to recorded sessions so you can review lessons anytime and reinforce your learning at your convenience.' },
  { title: 'Proven Placement Track Record', icon: '📈', description: 'We take pride in maintaining an excellent placement record, helping our students secure jobs in top companies.' }
];

module.exports = { courses, testimonials, services, stats, whyChooseUs };
