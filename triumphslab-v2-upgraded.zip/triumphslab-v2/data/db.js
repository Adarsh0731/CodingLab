// Simple in-memory store (replace with MongoDB/MySQL for production)
const bcrypt = require('bcryptjs');

const db = {
  users: [],
  enrollments: [],
  nextUserId: 1,
  nextEnrollmentId: 1,
  certificates: [],
  leads: [],
  passwordResets: {},

  // Quiz questions per course — admin can add/remove
  quizQuestions: {
    'manual-testing': [
      { id: 1, question: 'What is the primary goal of software testing?', options: ['Write code', 'Find defects and ensure quality', 'Design UI', 'Deploy application'], answer: 'Find defects and ensure quality' },
      { id: 2, question: 'Which type of testing is performed without executing code?', options: ['Unit testing', 'Integration testing', 'Static testing', 'System testing'], answer: 'Static testing' },
      { id: 3, question: 'What does STLC stand for?', options: ['Software Test Life Cycle', 'System Test Logic Cycle', 'Software Test Logic Check', 'None of above'], answer: 'Software Test Life Cycle' },
      { id: 4, question: 'Which document describes what to test and how?', options: ['Bug Report', 'Test Plan', 'Test Case', 'RTM'], answer: 'Test Plan' },
      { id: 5, question: 'Boundary Value Analysis is a type of?', options: ['Black Box Testing', 'White Box Testing', 'Grey Box Testing', 'Regression Testing'], answer: 'Black Box Testing' },
      { id: 6, question: 'Which testing verifies the system against requirements?', options: ['Unit', 'Integration', 'System', 'UAT'], answer: 'System' },
      { id: 7, question: 'A defect found after release is called?', options: ['Bug', 'Error', 'Production Defect', 'Incident'], answer: 'Production Defect' },
      { id: 8, question: 'Equivalence Partitioning divides input into?', options: ['Valid classes only', 'Invalid classes only', 'Valid and invalid classes', 'Random partitions'], answer: 'Valid and invalid classes' },
      { id: 9, question: 'Which test level tests individual components?', options: ['Integration', 'System', 'Unit', 'Acceptance'], answer: 'Unit' },
      { id: 10, question: 'Regression testing is performed after?', options: ['Requirements change', 'Code changes or bug fixes', 'UI redesign only', 'Load testing'], answer: 'Code changes or bug fixes' }
    ],
    'java-selenium': [
      { id: 1, question: 'Which method finds elements by CSS selector in Selenium?', options: ['findElement(By.id)', 'findElement(By.cssSelector)', 'findElement(By.name)', 'findElement(By.tagName)'], answer: 'findElement(By.cssSelector)' },
      { id: 2, question: 'TestNG annotation to run before each test method?', options: ['@BeforeClass', '@BeforeSuite', '@BeforeMethod', '@BeforeTest'], answer: '@BeforeMethod' },
      { id: 3, question: 'Which design pattern is commonly used in Selenium frameworks?', options: ['Singleton', 'Page Object Model', 'Factory', 'Observer'], answer: 'Page Object Model' },
      { id: 4, question: 'What does driver.quit() do?', options: ['Closes current window', 'Closes all windows and ends session', 'Minimizes browser', 'Refreshes page'], answer: 'Closes all windows and ends session' },
      { id: 5, question: 'Which wait is most recommended in Selenium?', options: ['Thread.sleep', 'Implicit Wait', 'Explicit Wait (WebDriverWait)', 'Static Wait'], answer: 'Explicit Wait (WebDriverWait)' },
      { id: 6, question: 'How do you handle alerts in Selenium?', options: ['driver.alert()', 'driver.switchTo().alert()', 'driver.getAlert()', 'Alert a = new Alert()'], answer: 'driver.switchTo().alert()' },
      { id: 7, question: 'What is the use of the Actions class in Selenium?', options: ['Take screenshots', 'Handle keyboard & mouse events', 'Manage frames', 'Handle cookies'], answer: 'Handle keyboard & mouse events' },
      { id: 8, question: 'Which method clears a text field in Selenium?', options: ['.clear()', '.reset()', '.empty()', '.delete()'], answer: '.clear()' },
      { id: 9, question: 'XPath starting with // means?', options: ['Absolute path', 'Relative path from root', 'Relative path from anywhere', 'Parent element'], answer: 'Relative path from anywhere' },
      { id: 10, question: 'What does By.xpath() return?', options: ['A WebElement', 'A By locator', 'A String', 'An int'], answer: 'A By locator' }
    ],
    'devops': [
      { id: 1, question: 'What does CI/CD stand for?', options: ['Code Integration/Code Deployment', 'Continuous Integration/Continuous Delivery', 'Continuous Improvement/Continuous Design', 'None'], answer: 'Continuous Integration/Continuous Delivery' },
      { id: 2, question: 'Which tool is primarily used for container orchestration?', options: ['Docker', 'Jenkins', 'Kubernetes', 'Ansible'], answer: 'Kubernetes' },
      { id: 3, question: 'Git command to create a new branch?', options: ['git new branch', 'git branch <name>', 'git checkout <name>', 'git clone <name>'], answer: 'git branch <name>' },
      { id: 4, question: 'What is a Dockerfile?', options: ['A script to run containers', 'A file with instructions to build a Docker image', 'A Docker network config', 'A Kubernetes manifest'], answer: 'A file with instructions to build a Docker image' },
      { id: 5, question: 'Jenkins is primarily a?', options: ['Version control tool', 'CI/CD automation server', 'Container runtime', 'Cloud provider'], answer: 'CI/CD automation server' },
      { id: 6, question: 'Infrastructure as Code tool by HashiCorp?', options: ['Ansible', 'Chef', 'Terraform', 'Puppet'], answer: 'Terraform' },
      { id: 7, question: 'Which command pushes a Docker image to a registry?', options: ['docker push', 'docker upload', 'docker send', 'docker publish'], answer: 'docker push' },
      { id: 8, question: 'What is a Kubernetes Pod?', options: ['A physical server', 'Smallest deployable unit containing containers', 'A Docker image', 'A CI pipeline stage'], answer: 'Smallest deployable unit containing containers' },
      { id: 9, question: 'Ansible uses which language for playbooks?', options: ['JSON', 'XML', 'YAML', 'Python'], answer: 'YAML' },
      { id: 10, question: 'What does git merge do?', options: ['Creates a new branch', 'Combines two branches', 'Deletes a branch', 'Resets changes'], answer: 'Combines two branches' }
    ],
    'api-postman': [
      { id: 1, question: 'REST API status code for successful POST (created)?', options: ['200', '201', '204', '400'], answer: '201' },
      { id: 2, question: 'What HTTP method is used to update a resource partially?', options: ['PUT', 'POST', 'PATCH', 'DELETE'], answer: 'PATCH' },
      { id: 3, question: 'In Postman, where do you write test scripts?', options: ['Pre-request Script', 'Tests tab', 'Headers tab', 'Authorization tab'], answer: 'Tests tab' },
      { id: 4, question: 'Which status code means Unauthorized?', options: ['403', '404', '401', '500'], answer: '401' },
      { id: 5, question: 'What is an API Collection in Postman?', options: ['A folder of requests', 'A test assertion', 'An environment variable', 'A mock server'], answer: 'A folder of requests' },
      { id: 6, question: 'pm.response.code refers to?', options: ['Request URL', 'Response status code', 'Response body', 'Header value'], answer: 'Response status code' },
      { id: 7, question: 'Content-Type header for JSON APIs?', options: ['text/plain', 'application/xml', 'application/json', 'multipart/form-data'], answer: 'application/json' },
      { id: 8, question: 'Which Postman feature allows automated test runs?', options: ['Mock Server', 'Collection Runner', 'API Monitor', 'Flows'], answer: 'Collection Runner' },
      { id: 9, question: 'Status 404 means?', options: ['Server Error', 'Unauthorized', 'Not Found', 'Bad Request'], answer: 'Not Found' },
      { id: 10, question: 'Bearer token is used for?', options: ['Content negotiation', 'Authentication/Authorization', 'Caching', 'Compression'], answer: 'Authentication/Authorization' }
    ],
    'appium': [
      { id: 1, question: 'Appium is used for testing?', options: ['Web apps', 'Mobile apps (Android & iOS)', 'Desktop apps', 'Databases'], answer: 'Mobile apps (Android & iOS)' },
      { id: 2, question: 'Appium uses which protocol?', options: ['HTTP', 'WebDriver Protocol', 'FTP', 'SOAP'], answer: 'WebDriver Protocol' },
      { id: 3, question: 'Which capability specifies device name in Appium?', options: ['platformName', 'deviceName', 'appPackage', 'automationName'], answer: 'deviceName' },
      { id: 4, question: 'UIAutomator2 is used for?', options: ['iOS automation', 'Android automation', 'Web automation', 'API testing'], answer: 'Android automation' },
      { id: 5, question: 'Which tool inspects mobile element locators?', options: ['Chrome DevTools', 'Appium Inspector', 'Firebug', 'Postman'], answer: 'Appium Inspector' },
      { id: 6, question: 'XCUITest automation engine is for?', options: ['Android', 'iOS', 'Windows', 'Linux'], answer: 'iOS' },
      { id: 7, question: 'Mobile gestures in Appium are handled via?', options: ['Actions class', 'TouchAction/W3C Actions', 'JavascriptExecutor', 'Robot class'], answer: 'TouchAction/W3C Actions' },
      { id: 8, question: 'appPackage capability refers to?', options: ['App file path', 'Android app package name', 'App version', 'Device OS'], answer: 'Android app package name' },
      { id: 9, question: 'Desired Capabilities configure?', options: ['Test assertions', 'Session (device, app, platform)', 'Alerts', 'Screenshots'], answer: 'Session (device, app, platform)' },
      { id: 10, question: 'How do you tap an element in Appium (Java)?', options: ['element.click()', 'element.tap()', 'element.touch()', 'element.press()'], answer: 'element.click()' }
    ],
    'jmeter': [
      { id: 1, question: 'JMeter is primarily used for?', options: ['UI testing', 'Performance/Load testing', 'Security testing', 'Mobile testing'], answer: 'Performance/Load testing' },
      { id: 2, question: 'What is a Thread Group in JMeter?', options: ['A group of HTTP requests', 'A set of virtual users', 'A listener', 'A timer'], answer: 'A set of virtual users' },
      { id: 3, question: 'Which JMeter element sends HTTP requests?', options: ['Thread Group', 'HTTP Request Sampler', 'Listener', 'Timer'], answer: 'HTTP Request Sampler' },
      { id: 4, question: 'Throughput in JMeter means?', options: ['Response time', 'Number of requests per second', 'Error rate', 'Latency'], answer: 'Number of requests per second' },
      { id: 5, question: 'JMeter is written in?', options: ['Python', 'Java', 'Ruby', 'JavaScript'], answer: 'Java' },
      { id: 6, question: 'Ramp-up period defines?', options: ['Test duration', 'Time to start all threads', 'Number of loops', 'Response timeout'], answer: 'Time to start all threads' },
      { id: 7, question: 'Assertions in JMeter verify?', options: ['Add delays', 'Response content', 'Parameterise requests', 'Record tests'], answer: 'Response content' },
      { id: 8, question: 'CSV Data Set Config is used for?', options: ['Storing results', 'Data parameterisation from CSV', 'Monitoring', 'Recording'], answer: 'Data parameterisation from CSV' },
      { id: 9, question: '90th percentile response time means?', options: ['Average time', '90% of requests completed within this time', 'Maximum time', 'Minimum time'], answer: '90% of requests completed within this time' },
      { id: 10, question: 'Which listener shows aggregate results?', options: ['View Results Tree', 'Aggregate Report', 'View Results in Table', 'Backend Listener'], answer: 'Aggregate Report' }
    ],
    'api-rest': [
      { id: 1, question: 'REST stands for?', options: ['Remote State Transfer', 'Representational State Transfer', 'Remote Service Technology', 'Resource State Transfer'], answer: 'Representational State Transfer' },
      { id: 2, question: 'Which HTTP method is idempotent and safe?', options: ['POST', 'PUT', 'GET', 'DELETE'], answer: 'GET' },
      { id: 3, question: 'RestAssured is a Java library for?', options: ['UI testing', 'Mobile testing', 'API testing', 'Database testing'], answer: 'API testing' },
      { id: 4, question: 'given().when().then() is pattern of?', options: ['TestNG', 'JUnit', 'RestAssured BDD style', 'Cucumber'], answer: 'RestAssured BDD style' },
      { id: 5, question: 'Status code 500 means?', options: ['Not Found', 'Forbidden', 'Internal Server Error', 'Bad Request'], answer: 'Internal Server Error' },
      { id: 6, question: 'OAuth 2.0 is used for?', options: ['Data encryption', 'Authorization', 'Load testing', 'Caching'], answer: 'Authorization' },
      { id: 7, question: 'JSON path to extract value in RestAssured?', options: ['response.body()', 'response.jsonPath().get("key")', 'response.extract("key")', 'response.path("key")'], answer: 'response.jsonPath().get("key")' },
      { id: 8, question: 'HTTPS differs from HTTP by?', options: ['Faster speed', 'Encrypted communication (SSL/TLS)', 'Port 8080', 'No headers'], answer: 'Encrypted communication (SSL/TLS)' },
      { id: 9, question: 'Serialisation in API testing means?', options: ['Converting object to JSON/XML', 'Parsing response', 'Validating schema', 'Sending request'], answer: 'Converting object to JSON/XML' },
      { id: 10, question: 'Which annotation in TestNG marks a test?', options: ['@Test', '@TestCase', '@Verify', '@Check'], answer: '@Test' }
    ]
  }
};

// Seed admin user on startup
(async () => {
  const adminPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@123', 10);
  db.users.push({
    id: 0,
    firstname: 'Admin',
    lastname: '',
    email: process.env.ADMIN_EMAIL || 'admin@triumphslab.com',
    phone: '',
    password: adminPassword,
    role: 'admin',
    createdAt: new Date()
  });
})();

module.exports = db;
