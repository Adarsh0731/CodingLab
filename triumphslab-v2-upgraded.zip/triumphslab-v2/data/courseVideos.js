// triumphslab/data/courseVideos.js
// Each entry: { video: '<youtube embed or watch url>', whatsapp: '<url>' }
// The video field accepts any YouTube URL format (embed, watch, youtu.be) or bare video ID.

const courseVideos = {
  'manual-testing': {
    video: 'https://www.youtube.com/embed/7i26m5f5Au0',
    whatsapp: 'https://chat.whatsapp.com/B5GaWRdT3VsKwCnJkvnSXo'
  },
  'java-selenium': {
    video: 'https://www.youtube.com/embed/gcwqsBc9T1w',
    whatsapp: ''
  },
  'devops': {
    video: 'https://www.youtube.com/embed/iO412okN9Ow',
    whatsapp: ''
  },
  'appium': {
    video: 'https://www.youtube.com/embed/pI5zrUhydyo',
    whatsapp: ''
  },
  'jmeter': {
    video: 'https://www.youtube.com/embed/krcZsOiIWTw',
    whatsapp: ''
  },
  'api-postman': {
    video: 'https://www.youtube.com/embed/vCJVFnepECc',
    whatsapp: 'https://chat.whatsapp.com/B5GaWRdT3VsKwCnJkvnSXo'
  },
  'api-rest': {
    video: 'https://www.youtube.com/embed/vCJVFnepECc',
    whatsapp: ''
  },
  'self-paced': {
    video: '',
    whatsapp: ''
  }
};

/**
 * Normalise any YouTube URL to a bare video ID.
 * Accepts: youtu.be/ID, youtube.com/watch?v=ID, youtube.com/embed/ID, or bare ID.
 */
function extractVideoId(url) {
  if (!url) return null;
  const patterns = [
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  if (/^[a-zA-Z0-9_-]{11}$/.test(url)) return url;
  return null;
}

/**
 * Return embed URL for a course, or '' if not set.
 */
function getEmbedUrl(courseId) {
  const entry = courseVideos[courseId];
  if (!entry) return '';
  const raw = typeof entry === 'string' ? entry : (entry.video || '');
  const id = extractVideoId(raw);
  return id ? `https://www.youtube.com/embed/${id}` : '';
}

module.exports = courseVideos;
module.exports.extractVideoId = extractVideoId;
module.exports.getEmbedUrl = getEmbedUrl;