// ===== Navbar Scroll Effect =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled');
    navbar.style.boxShadow = '0 4px 30px rgba(0,0,0,0.12)';
  } else {
    navbar.classList.remove('scrolled');
    navbar.style.boxShadow = '';
  }
});

// ===== Hamburger Menu =====
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('nav-menu');
if (hamburger && navMenu) {
  hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('open');
    hamburger.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
      navMenu.classList.remove('open');
      hamburger.classList.remove('open');
    }
  });
  // Close mobile nav when any link clicked
  navMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('open');
      hamburger.classList.remove('open');
    });
  });
}

// ===== Active Nav Link =====
const currentPath = window.location.pathname;
document.querySelectorAll('.nav-link').forEach(link => {
  const href = link.getAttribute('href');
  if (href && href !== '#' && currentPath === href) {
    link.style.color = 'var(--primary)';
    link.style.background = 'var(--primary-light)';
  }
});

// ===== Testimonial Slider =====
const track = document.getElementById('testimonial-track');
const dotsContainer = document.getElementById('slider-dots');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

if (track) {
  const cards = track.querySelectorAll('.testimonial-card');
  let current = 0;
  let perSlide = 3;
  let total = 0;
  let autoSlideInterval;

  function getPerSlide() {
    if (window.innerWidth <= 768) return 1;
    if (window.innerWidth <= 1024) return 2;
    return 3;
  }

  function buildDots() {
    dotsContainer.innerHTML = '';
    perSlide = getPerSlide();
    total = Math.ceil(cards.length / perSlide);
    for (let i = 0; i < total; i++) {
      const dot = document.createElement('div');
      dot.className = 'dot' + (i === current ? ' active' : '');
      dot.addEventListener('click', () => goTo(i));
      dotsContainer.appendChild(dot);
    }
  }

  function goTo(index) {
    perSlide = getPerSlide();
    total = Math.ceil(cards.length / perSlide);
    current = (index + total) % total;
    const cardWidth = cards[0].offsetWidth + 24;
    track.style.transform = `translateX(-${current * perSlide * cardWidth}px)`;
    document.querySelectorAll('.dot').forEach((d, i) => {
      d.classList.toggle('active', i === current);
    });
  }

  function startAuto() {
    autoSlideInterval = setInterval(() => goTo(current + 1), 4000);
  }

  buildDots();
  startAuto();

  if (prevBtn) prevBtn.addEventListener('click', () => { clearInterval(autoSlideInterval); goTo(current - 1); startAuto(); });
  if (nextBtn) nextBtn.addEventListener('click', () => { clearInterval(autoSlideInterval); goTo(current + 1); startAuto(); });
  window.addEventListener('resize', () => { buildDots(); goTo(0); });
}

// ===== Enrollment Form (homepage) =====
const enrollForm = document.getElementById('enroll-form');
if (enrollForm) {
  enrollForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = enrollForm.querySelector('button[type="submit"]');
    const msg = document.getElementById('enroll-msg');
    const formData = Object.fromEntries(new FormData(enrollForm));
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    try {
      const res = await fetch('/api/enroll', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      msg.className = 'form-msg ' + (data.success ? 'success' : 'error');
      msg.textContent = data.message;
      if (data.success) enrollForm.reset();
    } catch {
      msg.className = 'form-msg error';
      msg.textContent = 'Something went wrong. Please try again.';
    }
    btn.disabled = false;
    btn.innerHTML = 'Get Free Counselling <i class="fas fa-arrow-right"></i>';
  });
}

// ===== Contact Form =====
const contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('button[type="submit"]');
    const msg = document.getElementById('contact-msg');
    const formData = Object.fromEntries(new FormData(contactForm));
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    try {
      const res = await fetch('/api/contact', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      msg.className = 'form-msg ' + (data.success ? 'success' : 'error');
      msg.textContent = data.message;
      if (data.success) contactForm.reset();
    } catch {
      msg.className = 'form-msg error';
      msg.textContent = 'Something went wrong. Please try again.';
    }
    btn.disabled = false;
    btn.innerHTML = 'Send Message <i class="fas fa-paper-plane"></i>';
  });
}

// ===== Scroll Reveal Animation =====
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.1 });

document.querySelectorAll('.course-card, .why-card, .mission-card, .testimonial-card, .stat-item').forEach(el => {
  el.classList.add('reveal');
  observer.observe(el);
});

const revealStyle = document.createElement('style');
revealStyle.textContent = `
  .reveal { opacity: 0; transform: translateY(24px); transition: opacity 0.5s ease, transform 0.5s ease; }
  .reveal.visible { opacity: 1; transform: translateY(0); }
`;
document.head.appendChild(revealStyle);

// ===== Counter Animation =====
function animateCounter(el, target, suffix) {
  let start = 0;
  const step = target / 60;
  const timer = setInterval(() => {
    start += step;
    if (start >= target) { start = target; clearInterval(timer); }
    el.textContent = Math.floor(start) + suffix;
  }, 25);
}

const statObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target.querySelector('.stat-value');
      if (el && !el.dataset.animated) {
        el.dataset.animated = true;
        const raw = el.textContent;
        const num = parseInt(raw.replace(/\D/g, ''));
        const suffix = raw.replace(/[0-9]/g, '');
        animateCounter(el, num, suffix);
      }
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.stat-item').forEach(el => statObserver.observe(el));

// ===== WhatsApp Float =====
const wa = document.createElement('a');
wa.href = 'https://wa.me/919148819085?text=Hi%20TriumphsLab%2C%20I%20am%20interested%20in%20your%20courses';
wa.target = '_blank';
wa.rel = 'noopener';
wa.className = 'wa-float';
wa.innerHTML = '<i class="fab fa-whatsapp"></i><span class="wa-tooltip">Chat with us</span>';
document.body.appendChild(wa);

const waStyle = document.createElement('style');
waStyle.textContent = `
  .wa-float { position:fixed; bottom:28px; right:28px; z-index:9999; background:#25d366; color:#fff; width:56px; height:56px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:28px; box-shadow:0 4px 20px rgba(37,211,102,0.4); transition:transform 0.2s, box-shadow 0.2s; }
  .wa-float:hover { transform:scale(1.12); box-shadow:0 8px 28px rgba(37,211,102,0.5); color:#fff; }
  .wa-tooltip { position:absolute; right:68px; background:#333; color:#fff; font-size:13px; font-weight:500; padding:6px 12px; border-radius:8px; white-space:nowrap; opacity:0; pointer-events:none; transition:opacity 0.2s; font-family:'Poppins',sans-serif; }
  .wa-float:hover .wa-tooltip { opacity:1; }
  @media(max-width:480px){ .wa-float{ bottom:18px; right:18px; width:50px; height:50px; font-size:24px; } .wa-tooltip{display:none;} }
`;
document.head.appendChild(waStyle);

// ===== Back to Top =====
const topBtn = document.createElement('button');
topBtn.className = 'back-to-top';
topBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
topBtn.setAttribute('aria-label', 'Back to top');
topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
document.body.appendChild(topBtn);

window.addEventListener('scroll', () => {
  topBtn.classList.toggle('visible', window.scrollY > 400);
});

const topStyle = document.createElement('style');
topStyle.textContent = `
  .back-to-top { position:fixed; bottom:96px; right:28px; z-index:9998; background:var(--primary); color:#fff; width:44px; height:44px; border-radius:50%; border:none; cursor:pointer; font-size:16px; box-shadow:0 4px 16px rgba(26,115,232,0.3); opacity:0; transform:translateY(10px); transition:opacity 0.3s, transform 0.3s; display:flex; align-items:center; justify-content:center; }
  .back-to-top.visible { opacity:1; transform:translateY(0); }
  .back-to-top:hover { background:var(--primary-dark); transform:translateY(-2px); }
  @media(max-width:480px){ .back-to-top{ bottom:80px; right:18px; width:40px; height:40px; } }
`;
document.head.appendChild(topStyle);
