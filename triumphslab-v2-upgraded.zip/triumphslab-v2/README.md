# TriumphsLab — Practical IT Training & Career Support

A full-stack clone of [triumphslab.com](https://triumphslab.com) built with **Node.js + Express + EJS**.

---

## 🚀 Tech Stack

| Layer | Technology |
|-------|-----------|
| Runtime | Node.js |
| Framework | Express.js |
| Templating | EJS (Embedded JavaScript) |
| Styling | Custom CSS (no framework) |
| Icons | Font Awesome 6 |
| Fonts | Google Fonts (Poppins) |

---

## 📁 Project Structure

```
triumphslab/
├── server.js              # Main Express server
├── package.json
├── data/
│   └── siteData.js        # All site content (courses, testimonials, etc.)
├── routes/
│   ├── index.js           # Main page routes
│   ├── courses.js         # Course routes
│   └── api.js             # API endpoints
├── views/
│   ├── partials/
│   │   ├── header.ejs     # Shared header/nav
│   │   └── footer.ejs     # Shared footer
│   ├── index.ejs          # Homepage
│   ├── courses.ejs        # All courses listing
│   ├── course-detail.ejs  # Individual course page
│   ├── contact.ejs        # Contact page
│   ├── login.ejs          # Sign In page
│   ├── register.ejs       # Sign Up page
│   ├── service.ejs        # Service pages (reusable)
│   ├── jobs.ejs           # Job listing page
│   └── 404.ejs            # 404 error page
└── public/
    ├── css/
    │   └── style.css      # Main stylesheet
    └── js/
        └── main.js        # Frontend JavaScript
```

---

## ⚙️ Setup & Run

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
node server.js
```

### 3. Open in Browser
```
http://localhost:3000
```

---

## 🌐 Pages & Routes

| URL | Page |
|-----|------|
| `/` | Homepage |
| `/courses` | All Courses |
| `/courses/Manual_testing` | Manual Testing Course |
| `/courses/Java_with_selenium` | Java with Selenium |
| `/courses/Devops_course` | DevOps Course |
| `/courses/Appium` | Appium Mobile Automation |
| `/courses/Performance_testing` | JMeter Performance Testing |
| `/courses/Api_testing_postman` | API Testing with Postman |
| `/courses/Api_automation_rest` | REST Assured API Automation |
| `/courses/Manual_testing_video` | Self-Paced Learning |
| `/Mock_interview` | Mock Interview Service |
| `/Become_a_trainer` | Become a Trainer |
| `/Internship` | Internship for Students |
| `/International_certification` | International IT Certification |
| `/Resume_building` | Professional Resume Building |
| `/Job_listing` | Job Listing |
| `/Contact` | Contact Us |
| `/Login` | Sign In |
| `/Register` | Sign Up |

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/contact` | Submit contact form |
| `POST` | `/api/enroll` | Course enrollment inquiry |
| `GET` | `/api/courses` | Get all courses (JSON) |
| `GET` | `/api/testimonials` | Get all testimonials (JSON) |

---

## ✨ Features

- ✅ Responsive design (mobile, tablet, desktop)
- ✅ Sticky navbar with scroll effect
- ✅ Auto-sliding testimonials carousel
- ✅ Counter animations for stats
- ✅ Scroll-reveal animations
- ✅ Partner logo marquee scroll
- ✅ Contact & enrollment forms with API
- ✅ 8 courses with detail pages
- ✅ 5 service pages
- ✅ Login / Register pages
- ✅ 404 page

---

## 📞 Contact Info (from original site)

- **Phone:** (+91) 9579338436 / 07892787036
- **Email:** contact@triumpslab.com
- **Branches:** Bangalore | Mumbai | Pune
- **YouTube:** [@anp_tech6369](https://www.youtube.com/@anp_tech6369)
